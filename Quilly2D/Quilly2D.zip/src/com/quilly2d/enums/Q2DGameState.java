package com.quilly2d.enums;

public enum Q2DGameState
{
	RUNNIG, PAUSED, STOPPED;
}
